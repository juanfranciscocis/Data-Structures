

# First Homework
## Due: 2022-09-29
## CMP-3002-FALL22
## BY: JUAN FRANCISCO CISNEROS
## TEACHER: ALEJANDRO PROAÑO

### The problems can be found at https://github.com/aproano2/cmp-3002-fall22-aproano/tree/master/homework

